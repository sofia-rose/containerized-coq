#ifndef NLA_H
#define NLA_H

#include "literal.h"
#include "veriT-status.h"

#include "proof.h"

extern char * reduce_path;

/**
   \brief initializes the module
   \remarks must be called before any other function of the module */
extern void      NLA_init(void);

/**
   \brief releases the module */
extern void      NLA_done(void);

/**
   \brief activate NLA module */
extern void      NLA_activate(void);

/**
   \brief asserts a literal
   \param lit a literal */
extern Tstatus   NLA_assert(Tlit lit);

/**
   \brief clear the set of literals */
extern void      NLA_clear(void);

/**
   \brief check satisfiability of the set of given clues
   \return status of satisfiability after the check */
extern Tstatus   NLA_solve(void);

/**
   \brief Pushes onto veriT_conflict the set of lits that led to the conflict
   \pre NLA_status() yields UNSAT */
extern void      NLA_conflict(void);

#ifdef PROOF
extern Tproof    NLA_conflict_proof(void);
#endif

/**
   \brief Verifies if the module has a lemma to produce.
   \return \e true if it has a lemma to return, \e false otherwise. */
extern bool      NLA_has_lemma(void);

/**
   \brief Finds model equalities between shared variables
   \remark enqueue in xqueue the equalities
   \return true iff there has been equalities enqueued */
extern bool      NLA_model_eq(void);

#endif
