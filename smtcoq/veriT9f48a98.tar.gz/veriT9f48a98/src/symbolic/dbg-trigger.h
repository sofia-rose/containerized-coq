/**
   dbg-trigger: 

   resources to debug triggers.*/

#ifndef DBG_TRIGGER
#define DBG_TRIGGER

#include "DAG.h"

extern void dbg_trigger_print(TDAG DAG);

#endif
