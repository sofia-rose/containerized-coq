#ifndef DAG_TMP_H
#define DAG_TMP_H

#include "DAG.h"

/*
  --------------------------------------------------------------
  DAG_tmp functions
  --------------------------------------------------------------
*/

extern char * DAG_tmp;

#define DAG_tmp_bool ((unsigned char *) DAG_tmp)
#define DAG_tmp_unsigned ((unsigned *) DAG_tmp)
#define DAG_tmp_int ((int *) DAG_tmp)
#define DAG_tmp_DAG ((TDAG *) DAG_tmp)
#define DAG_tmp_stack_DAG ((Tstack_DAG *) DAG_tmp)

#ifdef DEBUG
extern void DAG_tmp_reserve(void);
extern void DAG_tmp_release(void);
#else
static inline void DAG_tmp_reserve(void) { }
static inline void DAG_tmp_release(void) { }
#endif

extern void DAG_tmp_reset_bool(TDAG DAG);
extern void DAG_tmp_reset_unsigned(TDAG DAG);
extern void DAG_tmp_reset_int(TDAG DAG);
extern void DAG_tmp_reset_DAG(TDAG DAG);
extern void DAG_tmp_reset_stack_DAG(TDAG DAG);
extern void DAG_tmp_free_DAG(TDAG DAG);

/*
  --------------------------------------------------------------
  Initialization-release functions
  --------------------------------------------------------------
*/

extern void DAG_tmp_init(void);
extern void DAG_tmp_done(void);

#ifdef DEBUG
extern void DAG_tmp_debug(void);
#endif

#endif
