#ifndef DIMACS_H
#define DIMACS_H

#include <stdio.h>

void      parse_dimacs (FILE * file);

#endif
