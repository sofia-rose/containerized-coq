#ifndef TPTP_H
#define TPTP_H

#include <stdio.h>

void parse_tptp(FILE * input, char * filename, bool option_disable_print_success);

#endif
