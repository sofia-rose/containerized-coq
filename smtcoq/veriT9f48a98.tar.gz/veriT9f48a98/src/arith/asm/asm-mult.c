/*
 * Temporary code to illustrate an assembly version for LAsigned_mult
 */
#include <limits.h>
#include <stdio.h>

/*
  Fast signed int integer multiplication with overflow detection

  Calls to this routine compiled with gcc -O2 result in:
  movl	$1, %esi  
  ## InlineAsm Start
  imull %edx, %ecx;
  cmovo %esi, %eax;   # cmovo has registers as operands

*/
static int overflow = 0;

#define SIGNED_MULT(a, b)                                     \
  __asm__ ( "movl $1, %%eax\n\t"                              \
            "imull %[multiplicand], %[target];\n\t"           \
	    "cmovo %%eax, %[overflow];\n\t"                   \
	    : [target] "+r" (a), [overflow] "+r" (overflow)   \
	    : [multiplicand]"r" (b)                           \
            : "eax")

int main (void)
{
  int a, b;
  int overflow;
  overflow = 0;
  printf("%i\n", INT_MAX);
  while (scanf("%i", &a) != 1) {}
  while (scanf("%i", &b) != 1) {}

  SIGNED_MULT(a, b);
  SIGNED_MULT(a, b);

  printf("%i, %i, %i\n", a, b, overflow);
  return 0;
}
