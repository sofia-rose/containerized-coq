/*
 *  Temporary code to illustrate a possible x86 assembly version for LAsigned_com
 */

#include <stdio.h>
#include <limits.h>

/* a := a * c - b * d + overflow detection
*/
static int overflow = 0;

#define SIGNED_COM(a, b, c, d)                                           \
  __asm__( "movl $1, %%eax;\n\t"                                         \
           "imull %[c], %[target];\n\t"                                  \
           "cmovo %%eax, %[overflow];\n\t"                               \
	   "imull %[d], %[b];\n\t"                                       \
           "cmovo %%eax, %[overflow];\n\t"                               \
	   "subl %[b], %[target];\n\t"                                   \
           "cmovo %%eax, %[overflow];\n\t"                               \
	   : [target] "+r" (a), [overflow] "+r" (overflow), [b] "+r" (b) \
	   : [c] "r" (c), [d] "r" (d))

int main (void)
{
  int a, b, c, d;
  int overflow;
  overflow = 0;
  printf("Enter four integers a b c d\n");
  while (scanf("%i %i %i %i", &a, &b, &c, &d) != 4) {}
  SIGNED_COM(a, b, c, d);
  printf("a = %i, b = %i, c = %i, d = %i, overflow = %i\n", a, b, c, d, overflow);
  return overflow;
}

/*
Apple clang version 3.1 (tags/Apple/clang-318.0.58) (based on LLVM 3.1svn)
Target: x86_64-apple-darwin11.4.2
Thread model: posix
Options: -O4 -g

Dump of assembler code from 0x100000e10 to 0x100000eb7:
0x0000000100000e10 <main+0>:	sub    $0x18,%rsp
0x0000000100000e14 <main+4>:	movl   $0x0,0x4(%rsp)
0x0000000100000e1c <main+12>:	lea    0x12d(%rip),%rdi        # 0x100000f50 <str>
0x0000000100000e23 <main+19>:	callq  0x100000ec4 <dyld_stub_puts>
0x0000000100000e28 <main+24>:	lea    0xe1(%rip),%rdi        # 0x100000f10
0x0000000100000e2f <main+31>:	lea    0x14(%rsp),%rsi
0x0000000100000e34 <main+36>:	lea    0x10(%rsp),%rdx
0x0000000100000e39 <main+41>:	lea    0xc(%rsp),%rcx
0x0000000100000e3e <main+46>:	lea    0x8(%rsp),%r8
0x0000000100000e43 <main+51>:	xor    %al,%al
0x0000000100000e45 <main+53>:	callq  0x100000eca <dyld_stub_scanf>
0x0000000100000e4a <main+58>:	mov    0x4(%rsp),%eax
0x0000000100000e4e <main+62>:	mov    0x14(%rsp),%ecx
0x0000000100000e52 <main+66>:	mov    0x8(%rsp),%edx
0x0000000100000e56 <main+70>:	mov    0xc(%rsp),%esi
0x0000000100000e5a <main+74>:	mov    0x10(%rsp),%edi
0x0000000100000e5e <main+78>:	imul   %esi,%ecx
0x0000000100000e61 <main+81>:	jo     0x100000e7d <COM_OVERFLOW>
0x0000000100000e67 <main+87>:	imul   %edx,%edi
0x0000000100000e6a <main+90>:	jo     0x100000e7d <COM_OVERFLOW>
0x0000000100000e70 <main+96>:	sub    %edi,%ecx
0x0000000100000e72 <main+98>:	jo     0x100000e7d <COM_OVERFLOW>
0x0000000100000e78 <main+104>:	jmpq   0x100000e82 <main>
0x0000000100000e7d <COM_OVERFLOW+0>:	mov    $0x1,%eax
0x0000000100000e82 <main+0>:	nop    
0x0000000100000e83 <main+1>:	lea    0x92(%rip),%rdi        # 0x100000f1c
0x0000000100000e8a <main+8>:	mov    %eax,0x4(%rsp)
0x0000000100000e8e <main+12>:	mov    %ecx,0x14(%rsp)
0x0000000100000e92 <main+16>:	mov    0x4(%rsp),%r9d
0x0000000100000e97 <main+21>:	mov    0x8(%rsp),%r8d
0x0000000100000e9c <main+26>:	mov    0xc(%rsp),%ecx
0x0000000100000ea0 <main+30>:	mov    0x10(%rsp),%edx
0x0000000100000ea4 <main+34>:	mov    0x14(%rsp),%esi
0x0000000100000ea8 <main+38>:	xor    %al,%al
0x0000000100000eaa <main+40>:	callq  0x100000ebe <dyld_stub_printf>
0x0000000100000eaf <main+45>:	mov    0x4(%rsp),%eax
0x0000000100000eb3 <main+49>:	add    $0x18,%rsp
0x0000000100000eb7 <main+53>:	retq   
End of assembler dump. */
