#include "recursion.h"

#include "LA-pre.h"

#include "totality.h"

#define DAG_LEQ(a, b) DAG_new_binary(PREDICATE_LEQ, a, b)

/*--------------------------------------------------------------*/

extern bool LA_enable_lemmas_totality;

static TDAG
rewrite_eq(TDAG src)
{
  TDAG dest;
  if (DAG_symb(src) != PREDICATE_EQ)
    return src;
  if (LA_enable_lemmas_totality)
    {
      TDAG DAG0 = DAG_LEQ(DAG_arg0(src), DAG_arg1(src));
      TDAG DAG1 = DAG_LEQ(DAG_arg1(src), DAG_arg0(src));
      totality_register(DAG_or2(DAG0, DAG1));
    }
  dest = DAG_dup(DAG_and2(DAG_LEQ(DAG_arg0(src), DAG_arg1(src)),
                          DAG_LEQ(DAG_arg1(src), DAG_arg0(src))));
  DAG_free(src);
  return dest;
}

/*--------------------------------------------------------------*/

void
LA_pre_array(unsigned n, TDAG * Psrc)
{
  structural_recursion_array(n, Psrc, rewrite_eq);
}

/*--------------------------------------------------------------*/
