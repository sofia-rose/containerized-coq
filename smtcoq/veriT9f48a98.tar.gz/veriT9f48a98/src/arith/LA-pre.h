#ifndef LA_PRE_H
#define LA_PRE_H

#include "veriT-DAG.h"

/**
   \brief quick and dirty (and temporary) hack for QF_LRA
   rewrites src to remove all equalities
   a = b --> a <= b and b <= a
   \param n number of formulas
   \param Psrc an array of n formulas
   \remark Psrc is modified to contain the rewritten formulas */
void      LA_pre_array(unsigned n, TDAG * Psrc);

#endif /* LA_PRE_H */
