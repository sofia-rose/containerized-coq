#ifndef __INST_PRE_H
#define __INST_PRE_H

#include "congruence.h"

/*
  --------------------------------------------------------------
  Preprocessing quantified formulas for instantiation
  --------------------------------------------------------------
*/



/*
  --------------------------------------------------------------
  Normal forms
  --------------------------------------------------------------
*/

/* [TODO] Should me merged into set_NFs */
/**
   \remark assumes tree structure (no "lets")
   \remark assumes DAG is in PNNF */
extern void set_CNF(TDAG DAG);

/**
   \brief computes prenexed NNF and CNF of quantified DAG with arbitrary boolean structure
   \param DAG a quantified formula
   \remark assumes tree structure (no "lets")

   \remark No miniscoping/Skolemization is done. Only prenex universal
   quantifiers not under the scope of existential ones. */
extern void set_NFs(TDAG DAG);

/**
    \author Haniel Barbosa

    \brief takes formula and for each quantifier occurrence puts it in prenexed
    NNF
    \param DAG a formula

    \remark Assumes no quantifier occurs

    \remark No miniscoping/Skolemization is done. Only prenex universal
    quantifiers not under the scope of existential ones.

    \remark Renames variables so that prenexing does not mess up univesal
    quantification. Does not account for existentials, so the latter may range
    over universally quantified variables (a subsequent call to qnt_tidy will be
    required then)

    \remark Not sure about how destructive it is */
extern TDAG qnt_NF(TDAG DAG);

extern TDAG qnt_connectives(TDAG DAG);
extern TDAG qnt_NNF(TDAG src);
extern TDAG qnt_uniq_vars(TDAG DAG);

/*
  --------------------------------------------------------------
  Triggers
  --------------------------------------------------------------
*/

/**
    \author David Deharbe, Pascal Fontaine, Haniel Barbosa
    \brief inspects the whole formula, adds trigger to every quantified formula
    without triggers, and ensures the triggers are on the formula itself, not on
    the body
    \param DAG the formula */
extern void set_triggers_old(TDAG DAG);

/**
    \author Haniel Barbosa

    \brief computes triggers for a (universally) quantified formula and its
    quantified subformulas

    \param DAG a formula
    \param previous_vars variables from previous quantifiers
    \param triggers accumulates triggers found in nested quantifiers

    \remark assumes that DAG is in NNF and that no variable is bound by more
    than one quantifier (stronger than ca pture, as it does not require that the
    variable be under the scope of those quantifiers) */
extern void
set_triggers(TDAG DAG, Tstack_DAG trigger_vars, Tstack_DAGstack * triggers);

/**
    \author Haniel Barbosa

    \brief computes nested triggers for a (universally) quantified formula and its
    quantified subformulas

    \param DAG a formula
    \param previous_vars variables from previous quantifiers
    \param triggers accumulates triggers found in nested quantifiers

    \remark assumes that DAG is in NNF and that no variable is bound by more
    than one quantifier (stronger than ca pture, as it does not require that the
    variable be under the scope of those quantifiers) */
extern void
set_nested_triggers(TDAG DAG, Tstack_DAG previous_vars,
                    Tstack_DAGstack * triggers);

/** Should disappear */
extern void inst_pre(TDAG src);

/*
  --------------------------------------------------------------
  Symbols
  --------------------------------------------------------------
*/

#endif
