#ifndef __INST_TRIGGER_NEW_H
#define __INST_TRIGGER_NEW_H

#include "ccfv.h"

extern void triggers_init(void);
extern void triggers_done(void);

extern Tstack_DAGinst triggers(void);

#endif
