/*
  --------------------------------------------------------------
  Module for removing distinct constructs in formulas

  Protocol:
  (distinct_elimit_init; distinct_elim*; distinct_elim_done)*

  --------------------------------------------------------------
*/

#ifndef DISTINCT_ELIM_H
#define DISTINCT_ELIM_H

#include "DAG.h"
#include "proof.h"

/**
   \author Pascal Fontaine
   computes a distinct-free equivalent term (or formula)
   \param DAG the term (or formula) with distinct
   \return The distinct-free equivalent term (or formula)
   \remarks Non destructive
   \remarks DAG-linear (quadratic for distincts)
   \remarks no particular requirements on formula (no variable capture,
   behaves honestly with quantifiers)
   \pre none
   \post distinct-free term
*/
TDAG      distinct_elim(TDAG DAG);

/** \brief initializes module (mandatory) */
void distinct_elim_init(void);

/** \brief frees resources allocated by module */
void distinct_elim_done(void);

#endif
