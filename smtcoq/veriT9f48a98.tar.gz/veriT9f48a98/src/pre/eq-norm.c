#include "eq-norm.h"
#include "recursion.h"

/* #define DEBUG_EQ_NORM */

/*--------------------------------------------------------------*/

static TDAG
eq_norm_aux(TDAG src)
{
  TDAG dest;
  if (DAG_symb(src) != PREDICATE_EQ || DAG_sort(DAG_arg0(src)) != SORT_BOOLEAN)
    return src;
  dest = DAG_dup(DAG_equiv(DAG_arg0(src), DAG_arg1(src)));
  DAG_free(src);
  return dest;
}

/*--------------------------------------------------------------*/

TDAG
eq_norm(TDAG src)
{
  TDAG dest;
#ifdef DEBUG_EQ_NORM
  my_DAG_message("Before equality normalization\n%D\n", src);
#endif
  dest = structural_recursion(src, eq_norm_aux);
#ifdef DEBUG_EQ_NORM
  my_DAG_message("After equality normalization\n%D\n", dest);
#endif
  return dest;
}

/*--------------------------------------------------------------*/
