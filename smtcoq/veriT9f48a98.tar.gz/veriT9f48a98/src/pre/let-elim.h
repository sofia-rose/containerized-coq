/*
  --------------------------------------------------------------
  Module for removing let constructs in formulas
  --------------------------------------------------------------
*/

#ifndef LET_ELIM_H
#define LET_ELIM_H

#include "DAG.h"

void      let_elim_init(void);
void      let_elim_done(void);

/**
   \author Pascal Fontaine
   computes a let-free equivalent term (or formula)
   \param DAG the term (or formula) with let
   \return The let-free equivalent term (or formula)
   \remarks Non destructive
   \remarks tree-linear (DAG-exponential)
   \remarks this high complexity is acceptable because this is applied on the
   input formula before let expansion (i.e, before the tree explodes)
   \remarks no particular requirements on formula (no variable capture,
   behaves honestly with quantifiers)
   \remarks the formula should have been pre-processed by binder_rename
   to avoid capture
   \pre requires the term not to have a binder on a variable in the
   scope of another binder on that variable
   \remarks for instance it breaks on
   forall y . .... let x=phi(y) .... forall y ... x...
   \post returns a let-free term
   \remarks breaks the post-condition of binder-rename */
TDAG      let_elim(TDAG DAG);

/**
   \brief array version of the let_elim function
   \remark Destructive
   \see let_elim */
void    let_elim_array(unsigned n, TDAG * Psrc);

#endif
