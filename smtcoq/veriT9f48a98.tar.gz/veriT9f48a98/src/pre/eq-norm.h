/*
  --------------------------------------------------------------
  Module for turning equalities over propositions into equivs
  --------------------------------------------------------------
*/

#ifndef EQ_NORM_H
#define EQ_NORM_H

#include "DAG.h"

/**
   \author Haniel Barbosa
   \brief turns equalities between propositions into equivalencies
   \param DAG the term (or formula) with equalities over propositions
   \return The term (or formula) with only equivalencies over propositions
   \remarks Non destructive
   \remarks DAG-linear */
TDAG      eq_norm (TDAG DAG);

#endif
