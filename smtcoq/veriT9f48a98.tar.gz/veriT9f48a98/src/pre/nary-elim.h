/*
  --------------------------------------------------------------
  Module for removing nary constructs in formulas
  --------------------------------------------------------------
*/

#ifndef NARY_ELIM_H
#define NARY_ELIM_H

#include "DAG.h"

void      nary_elim_init (void);
void      nary_elim_done (void);

/**
   \author Pascal Fontaine
   computes an equivalent term (or formula) where all n-ary symbols
   are reduced to binary ones (except AND and OR)
   \param DAG the term (or formula) with n-ary symbols
   \return The equivalent term (or formula) with only binary symbols
   \remarks Non destructive
   \remarks DAG-linear
   \remarks no particular requirements on formula (no variable capture,
   behaves honestly with quantifiers)
   \remarks works now for implication, equiv, xor, -, <=, <, =, >=, >
   \pre none
   \post no n-ary for implication, equiv, xor, -, <=, <, =, >=, >
*/

TDAG      nary_elim (TDAG DAG);

#endif
