/**
  \file proof_id.h
  \author Pascal Fontaine
  \brief proof id definition
  This module provides API functions to memorize the proofs done in
  veriT */
#ifndef __PROOF_ID_H
#define __PROOF_ID_H

#include "config.h"

#ifdef PROOF

typedef unsigned Tproof;

#endif /* PROOF */

#endif /* __PROOF_ID_H */
